﻿<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://epc.accenture.com/2013/06/26/Type" xmlns:Util="urn:Util" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs msxsl xsl Util">
  <xsl:import href="PartyLicenseTemplate_DuckToASW.xslt"/>
  <xsl:template match="/">
    <xsl:for-each select="PartyRecord">
      <xsl:call-template name="partyLicense" />
    </xsl:for-each>
  </xsl:template>
</xsl:stylesheet>